This folder contains an application deployed using the Marmalade SDK.

    Application : Box2D
        Version : 0.0.1
    SDK Version : 6.1.1 [326649]
  Date Deployed : Wed Sep 26 20:42:46 2012
      Target OS : win32-sim (Windows (Simulator))
  Configuration : Release
