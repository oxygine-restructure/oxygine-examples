This folder contains an application deployed using the Marmalade SDK.

    Application : example2
        Version : 0.0.1
    SDK Version : 5.2.2 [303458]
  Date Deployed : Sat Mar 03 19:37:59 2012
      Target OS : win32-sim (Windows (Simulator))
  Configuration : Release
