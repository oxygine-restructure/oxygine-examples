This folder contains an application deployed using the Marmalade SDK.

    Application : demo_src
        Version : 0.0.1
    SDK Version : 6.2.1 [336699]
  Date Deployed : Mon Apr 08 03:33:47 2013
      Target OS : win32 (Windows)
  Configuration : Release
